﻿using System;
using System.Collections.Generic;

namespace SeminarioV.Models
{
    public partial class Editoras
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
