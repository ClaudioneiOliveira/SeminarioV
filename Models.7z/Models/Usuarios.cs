﻿using System;
using System.Collections.Generic;

namespace SeminarioV.Models
{
    public partial class Usuarios
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
